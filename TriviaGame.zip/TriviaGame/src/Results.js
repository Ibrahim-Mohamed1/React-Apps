import React, { Component } from 'react';

class Results extends Component {
    render() {
        return (
            <div>
                <h1 style={{color: "red"}}>Results</h1>
            </div>
        );
    }
}

export default Results;