import React, { Component } from 'react';
import { withData } from './Context';
import Atob from 'atob'
import Results from './Results.js';

class Game extends Component {
    constructor() {
        super()
        this.state = {
            answer: '',
            num: 0,
            buttonText: 'Next',
            gameOver: false
        }
    }

    handleNext () {
        var num = this.state.num
        if (num < this.props.questions - 1) {
            this.setState(prevState => ({
                num: prevState.num + 1
            }))
        } else (
            this.setState({ gameOver: true, buttonText: "Results" })
        )
    }
    checkAnswer = (e) => {
        let question = this.props.result.results[0] ? this.props.result.results[this.state.num] : this.props.result.results[this.state.num]
        let answer = question.correct_answer;
        if (e.target.value === answer) {
            e.target.style.backgroundColor = 'green'
            setTimeout(() => {
                e.target.style.backgroundColor = 'white'
                this.handleNext()
            }, 2000);
        }
    }
    render() {
        var stuff = this.props.result.results[0] ? this.props.result.results : this.props.result.results
        var mappedTrivia = stuff.map((item, i) => {

            if (item.type === 'bXVsdGlwbGU=') {
                let arr = []
                arr.push(item.incorrect_answers[0], item.incorrect_answers[1], item.incorrect_answers[2], item.correct_answer)
                let shuffled = arr
                    .map((a) => ({ sort: Math.random(), value: a }))
                    .sort((a, b) => a.sort - b.sort)
                    .map((a) => a.value)
                return (
                    <div>
                        <h1>{Atob(item.category)}</h1>
                        <h4>{Atob(item.difficulty)}</h4>
                        <h1>{Atob(item.question)}</h1>
                        <button className='answerButton' onClick={this.checkAnswer } value={shuffled[0]}>{Atob(shuffled[0])}</button>
                        <button className='answerButton' onClick={this.checkAnswer } value={shuffled[1]}>{Atob(shuffled[1])}</button>
                        <button className='answerButton' onClick={this.checkAnswer } value={shuffled[2]}>{Atob(shuffled[2])}</button>
                        <button className='answerButton' onClick={this.checkAnswer } value={shuffled[3]}>{Atob(shuffled[3])}</button>
                    </div>
                )
            } else {
                let arr = []
                arr.push(item.incorrect_answers[0], item.correct_answer)
                let shuffled = arr
                    .map((a) => ({ sort: Math.random(), value: a }))
                    .sort((a, b) => a.sort - b.sort)
                    .map((a) => a.value)
                return (
                    <div>
                        <h1>{Atob(item.category)}</h1>
                        <h4>{Atob(item.difficulty)}</h4>
                        <h1>{Atob(item.question)}</h1>
                        <button className='answerButton' onClick={this.checkAnswer} value={shuffled[0]}>{Atob(shuffled[0])}</button>
                        <button className='answerButton' onClick={this.checkAnswer} value={shuffled[1]}>{Atob(shuffled[1])}</button>
                    </div>
                )
            }
        })
        return (
            <>
                {this.state.gameOver === true ?
                    <Results /> :
                    <div>
                        <div>
                            {mappedTrivia[this.state.num]}
                        </div>
                        <button onClick={() => this.handleNext()}>{this.state.buttonText}</button>
                    </div>
                }
            </>
        );
    }
}

export default withData(Game);