import React, { Component } from 'react';

class Food extends Component {
    render() {
        return (
            <div>
                <h1>Food</h1>
            </div>
        );
    }
}

export default Food;