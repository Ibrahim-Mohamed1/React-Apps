import React, { Component } from 'react';

class Currency extends Component {
    render() {
        return (
            <div>
                <h1>Currency</h1>
            </div>
        );
    }
}

export default Currency;