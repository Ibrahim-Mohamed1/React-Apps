import React from 'react';
import './App.css'
import Home from './Home'

const App = () => {
  return (
    <div>
      <Home/>
    </div>
  );
};

export default App;