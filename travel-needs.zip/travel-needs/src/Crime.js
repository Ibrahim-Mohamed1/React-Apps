import React, { Component } from 'react';

class Crime extends Component {
    render() {
        return (
            <div>
                <h1>Crime</h1>
            </div>
        );
    }
}

export default Crime;