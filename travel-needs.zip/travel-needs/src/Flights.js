import React, { Component } from 'react';

class Flights extends Component {
    render() {
        return (
            <div>
                <h1>Find Flights</h1>
            </div>
        );
    }
}

export default Flights;